# Marvel CRUD (Express + React Vite + Tailwind)

Projet complet avec un backend Express (CRUD sur `characters.json`) et un frontend React avec Vite et TailwindCSS.

## Démarrage rapide

### 1) Backend
```bash
cd backend
npm install
npm start
# -> http://localhost:8080
```

### 2) Frontend
Dans un autre terminal :
```bash
cd frontend
npm install
npm run dev
# -> http://localhost:5173
```

## Endpoints API
- `GET /characters`
- `GET /characters/:id`
- `POST /characters` (body JSON: `{ name, realName, universe }`)
- `PUT /characters/:id` (body JSON: champs à modifier)
- `DELETE /characters/:id`

## Notes
- TailwindCSS est activé via le plugin `@tailwindcss/vite` et `@import "tailwindcss";` dans `src/index.css`.
- Si tu changes le port backend, mets à jour la constante `API` dans `src/App.jsx`.
